#meals = ['pasta', 'pizza', 'salad']

#for meal in meals:
#    print(meal.capitalize())
#
#print("bye")

members = ["john smith", "sen plakay", "dora ngacely"]

for member in members:
    print(member.title())