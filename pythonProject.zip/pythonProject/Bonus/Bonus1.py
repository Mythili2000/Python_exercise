text = input("Enter a name:")

length = len(text)

print(length)