a = [1,2,3,4,5,6]
a.insert(0,12)
a.append(7)
a.remove(3)# 3 value will remove
a.pop(3)
a[3] = 100# 3rd position will remove
print(a)