sum = 0
for i in range(1,51):
    if i % 2 == 0:
        sum = sum + i
        print("The sum of all numbers",sum)
