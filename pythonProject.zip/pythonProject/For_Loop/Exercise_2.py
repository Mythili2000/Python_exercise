#get input for a and b print numbers between both a and b
a = int(input("Enter an integer1:"))
b = int(input("Enter an integer2:"))
for i in range(a+1,b):
    print(i)