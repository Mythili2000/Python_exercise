number = int(input("Enter a number of terms:"))
for i in range(1,1+number):
    cube = i*i*i
    print("Number is:"+str(i),"and cube of the" +str(i),"is:",cube)
