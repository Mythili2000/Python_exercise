#print even numbers between the range
a = int(input("Enter an integer 1:"))
b = int(input("Enter an integer 2:"))
for i in range(a,b):
    if i % 2 == 0:
        print(i)