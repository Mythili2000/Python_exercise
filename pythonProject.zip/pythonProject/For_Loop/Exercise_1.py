#multiplication
for i in range(1,101):
    mul = i * 2
    print(i,"x 2 =",mul)