names = ["mythili","manoj","rajini","shankar"]
for i in names:
    print(i.upper())