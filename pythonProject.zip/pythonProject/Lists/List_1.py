a = []
for i in range(1,6):
    a.append(i)
print(a)