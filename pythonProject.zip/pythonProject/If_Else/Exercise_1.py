#Write a program that takes an integer input from the user and prints whether it's positive, negative, or zero.
my_integer = int(input("Enter an integer:"))

if (my_integer > 0):
    print("Positive")

elif (my_integer < 0):
    print("Negative")

else:
    print("Zero")