number = int(input("Enter an integer:"))
if number > 0:
    print("The",number,"is Positive")

elif number < 0:
    print("The",number,"is Negative")

else:
    print("The",number,"is Zero")

