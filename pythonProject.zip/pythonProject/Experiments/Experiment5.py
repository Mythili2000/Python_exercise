with open("files/doc.txt", "r") as file:
    file.read()

