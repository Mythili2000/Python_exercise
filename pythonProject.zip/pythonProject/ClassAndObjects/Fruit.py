class fruit():
    def __init__(self,col):
        self.color=col
apple = fruit("red")
print(apple.color)