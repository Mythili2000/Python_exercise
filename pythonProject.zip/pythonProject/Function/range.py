def printrange(range1,range2):
    for i in range(a,b):
        print(i, end = " ")
a = int(input("enter a number1:"))
b = int(input("enter a number2:"))
print("The range from", a, "to", b, "is")
printrange(a,b)


