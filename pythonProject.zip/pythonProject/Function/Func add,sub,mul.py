#a = int(input("Enter an integer1:"))
#b = int(input("Enter an integer2:"))
def add():
    print("Addition:")
    a = int(input("Enter an integer1:"))
    b = int(input("Enter an integer2:"))
    print("The sum of number is:",a + b)
def sub():
    print("Subtraction:")
    a = int(input("Enter an integer1:"))
    b = int(input("Enter an integer2:"))
    print("The subtraction of number is:", a - b)
def mul():
    print("Multiplication:")
    a = int(input("Enter an integer1:"))
    b = int(input("Enter an integer2:"))
    print("The multiplication of number is:", a * b)
def div():
    print("Division:")
    a = int(input("Enter an integer1:"))
    b = int(input("Enter an integer2:"))
    print("The division of number is:", a / b)

add()
sub()
mul()
div()



