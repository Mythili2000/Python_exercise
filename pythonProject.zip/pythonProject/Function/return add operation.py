a = int(input("Enter an integer a:"))
b = int(input("Enter an integer b:"))
c = int(input("Enter an integer c:"))
def add():
    return a + b
sum = add()
output = sum * c
print("The sum of a and b is:",sum)
print("The value of (a+b)*c is:",output)

