#Create a tuple of months in a year and print it.
#Access and print the third element of the tuple.

months = ("January","february","march","april","may","june","july","august","september","october","november","december")
print(months[2])