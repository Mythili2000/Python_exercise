#Create a list of numbers and use a loop to print each number multiplied by 2.

numbers = [1,2,3,4,5,6,7,8,9,10]

for i in numbers:
    result = i * 2
    print(result)