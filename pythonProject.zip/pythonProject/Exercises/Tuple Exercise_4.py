#Write a program that swaps the values of two variables using tuples.
x =5
y = 10

print("Before swapping")
print("x=",x)
print("y=",y)

x,y = y,x

print("After swapping")
print("x=",x)
print("y=",y)


