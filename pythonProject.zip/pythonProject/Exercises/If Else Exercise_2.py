#get an input for bvariable a and check whether the number is even or odd
a = int(input("Enter a number:"))
if (a % 2 == 0) :
    print("It is even number")

else:
    print("It is an odd number")
