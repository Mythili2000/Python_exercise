name = input("Enter your name:")
age = input("Enter your age:")
print("My name is" ,name,"and I am" ,age, "years old")