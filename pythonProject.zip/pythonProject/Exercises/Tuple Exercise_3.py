#Unpack the tuple into separate variables and print them.

person = ("Mythili",23,"Vellore")

name,age,city = person

print("Name:",name)
print("Age:",age)
print("City:",city)