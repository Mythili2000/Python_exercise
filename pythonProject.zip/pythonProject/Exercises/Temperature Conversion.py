input("Pick your current mood Happy, Sad, Depression, Cry, Shy, Emotional, Excited: ")
print("Well I wish your day should become a memorable day in your chapter")
Temp_Fahrenheit = int(input("Enter a temperature in your city: "))
celsius = Celsius = ((Temp_Fahrenheit - 32) * 5) / 9
print(celsius)