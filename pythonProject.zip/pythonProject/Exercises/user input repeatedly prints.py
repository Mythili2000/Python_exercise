
while True:
    user = input("what is your name?")
    print(user.capitalize())