#Create a dictionary of fruits and their corresponding colors. Print the dictionary.

fruits = {"apple":"red","orange":"orange","mango":"yellow"}
print(fruits)
new_fruit = "grape"
new_color = "purple"
fruits[new_fruit] = new_color
print("Updated list of fruits:",new_fruit + ":")
print(fruits)