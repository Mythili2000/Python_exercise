#Create a list of tuples, each containing a name and an age. Print the list
biodata = [("Name:mythili",23),("Name:Manoj",20),("Name:Rajini",56),("Name:shankar",62)]
print(biodata)