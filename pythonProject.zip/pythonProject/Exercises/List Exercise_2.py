#Write a program that calculates the sum of all numbers in a given list.

list  = [11,23,45,67,89,65,0]
print(sum(list))