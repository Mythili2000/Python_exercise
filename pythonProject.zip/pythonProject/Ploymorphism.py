# Method overriding
class animal():
    def sound(self):
        print("Animal makes sound")
class dog(animal):
    def sound(self):
        print("Dog barks")
class bird(animal):
    def sound(self):
        print("Birds sing")
b1 = bird()
b1.sound()